import sys
import csv
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidget, QTableWidgetItem

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Prospect Data')
        self.setGeometry(100, 100, 800, 600)

        table = QTableWidget(self)
        table.setGeometry(50, 50, 700, 500)

        with open('prospect_data.csv', mode='r') as file:
            reader = csv.reader(file)
            headers = next(reader)
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)

            for i, row in enumerate(reader):
                table.insertRow(i)
                for j, col in enumerate(row):
                    table.setItem(i, j, QTableWidgetItem(col))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
